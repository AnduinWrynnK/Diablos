//
//  ViewController.m
//  runloop
//
//  Created by xu yongpan on 2020/2/18.
//  Copyright © 2020 xu yongpan. All rights reserved.
//

#import "ViewController.h"
#import <MapKit/MapKit.h>
#import "SQRunLoopSource.h"
@interface ViewController ()<MKMapViewDelegate>
{
    BOOL _end;
}
@property (nonatomic,strong)  UIScrollView *testScrollview;
@property (nonatomic,readwrite,retain) SQRunLoopSource *source;
@property (nonatomic,weak) NSThread *aThread;
@end

@implementation ViewController

static int a;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.testScrollview=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
    self.testScrollview.backgroundColor=[UIColor orangeColor];
    
    [self.view addSubview:self.testScrollview];
    self.testScrollview.contentSize = CGSizeMake(self.view.bounds.size.width, self.view.bounds.size.height * 4);
//    self.testScrollview.hidden=true;
    [self test8];
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    NSLog(@"");
}
static NSString *CustomRunLoopMode = @"CustomRunLoopMode";

-(void)printMessage:(NSTimer *)timer{
    a++;
    NSLog(@"%d",a);
}
void myRunLoopObserver(CFRunLoopObserverRef observer,CFRunLoopActivity activity, void *info){
    switch (activity) {
        case kCFRunLoopEntry:
            NSLog(@"即将进入循环");
            break;
            case kCFRunLoopBeforeTimers:
            NSLog(@"即将处理定时器");
            break;
            case kCFRunLoopBeforeSources:
            NSLog(@"即将处理输入源");
            break;
            case kCFRunLoopBeforeWaiting:
            NSLog(@"即将休眠");
            break;
            case kCFRunLoopAfterWaiting:
            NSLog(@"即将唤醒");
            break;
            case kCFRunLoopExit:
            NSLog(@"即将退出循环");
            break;
            
        default:
            break;
    }
}
-(void)test2{
    NSLog(@"CFRunLoopGetMain---------%@",CFRunLoopGetMain());//主线程
    NSLog(@"----currentRunLoop-------%@",[NSRunLoop currentRunLoop]);//当前为主线程
    
    dispatch_async(dispatch_get_main_queue(), ^{
        NSLog(@"---async---currentRunLoopdispatch_get_main_queue---currentRunLoop----%@",[NSRunLoop currentRunLoop]);//当前为主线程

    });
    dispatch_async(dispatch_queue_create("test1", NULL), ^{
        NSLog(@"--async---dispatch_queue_create(test1, NULL)----currentRunLoop----%@",[NSRunLoop currentRunLoop]);//当前为支线程
    });
    dispatch_sync(dispatch_queue_create("test2", NULL), ^{
        NSLog(@"--sync----dispatch_queue_create(test2, NULL)---currentRunLoop-----%@",[NSRunLoop currentRunLoop]);//当前为主线程
    });
}
-(void)test1{
    self.testScrollview.hidden=false;
    
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(printMessage:) userInfo:nil repeats:true];
    [[NSRunLoop currentRunLoop] addTimer:timer forMode:UITrackingRunLoopMode];
}
/**
 *
 *  可以检查RunLoop的退出
 *
 */
- (void)test3
{
    BOOL done = NO;
    do{
        SInt32 result = CFRunLoopRunInMode(kCFRunLoopDefaultMode, 10, YES);
        if ((result == kCFRunLoopRunStopped) || (result == kCFRunLoopRunFinished))
            done = YES;
    }
    while (!done);
}
-(void)test4{
    NSLog(@"支线程使用定时器");
    [NSThread detachNewThreadSelector:@selector(newThreadAction) toTarget:self withObject:nil];
}
-(void)newThreadAction{
    NSRunLoop *runloop=[NSRunLoop currentRunLoop];
    CFRunLoopObserverContext context = {0, (__bridge void *)(self), NULL, NULL, NULL};
       CFRunLoopObserverRef observer = CFRunLoopObserverCreate(kCFAllocatorDefault,kCFRunLoopAllActivities, YES, 0, &myRunLoopObserver, &context);
    if (observer){
        CFRunLoopRef cfLoop = [runloop getCFRunLoop];
        CFRunLoopAddObserver(cfLoop, observer, kCFRunLoopDefaultMode);
    }
    //在当前线程中注册事件源
    [NSTimer scheduledTimerWithTimeInterval: 1 target: self selector:@selector(printMessage:) userInfo: nil
                                    repeats:YES];
    
    NSInteger loopCount = 5;
    do{
        [runloop runMode:NSDefaultRunLoopMode beforeDate:[NSDate dateWithTimeIntervalSinceNow:2.0]];//runloop以某个模式运行一段时间
        loopCount--;
        
    }while (loopCount);
    
}
/**
 *
 *  自定义timer
 *
 */
-(void)test5{
    // 获得当前thread的Run loop
    NSRunLoop* myRunLoop = [NSRunLoop currentRunLoop];
    // 设置Run Loop observer的运行环境
    CFRunLoopObserverContext context = {0, (__bridge void *)(self), NULL, NULL, NULL};
    
    // 创建Run loop observer对象
    // 第一个参数用于分配该observer对象的内存
    // 第二个参数用以设置该observer所要关注的的事件，详见回调函数myRunLoopObserver中注释
    // 第三个参数用于标识该observer是在第一次进入run loop时执行还是每次进入run loop处理时均执行
    // 第四个参数用于设置该observer的优先级
    // 第五个参数用于设置该observer的回调函数
    // 第六个参数用于设置该observer的运行环境
    CFRunLoopObserverRef observer = CFRunLoopObserverCreate(kCFAllocatorDefault,kCFRunLoopAllActivities, YES, 0, &myRunLoopObserver, &context);
    if (observer){
        CFRunLoopRef cfLoop = [myRunLoop getCFRunLoop];
        CFRunLoopAddObserver(cfLoop, observer, kCFRunLoopDefaultMode);
    }
    CFRunLoopRef runLoop = CFRunLoopGetCurrent();
    CFRunLoopTimerContext timerContext = {0, NULL, NULL, NULL, NULL};
    CFRunLoopTimerRef timer = CFRunLoopTimerCreate(kCFAllocatorDefault, 0.1, 1, 0, 0,
                                                   &myCFTimerCallback, &timerContext);
    
    CFRunLoopAddTimer(runLoop, timer, kCFRunLoopCommonModes);
    NSInteger loopCount = 2;
    do{
        [[NSRunLoop currentRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:1]];
        loopCount--;
    }while (loopCount);

}
/**
 *
 *  使用系统的timer(添加observe)
 *
 */
- (void)test6{
    // 获得当前thread的Run loop
    NSRunLoop* myRunLoop = [NSRunLoop currentRunLoop];
    // 设置Run Loop observer的运行环境
    CFRunLoopObserverContext context = {0, (__bridge void *)(self), NULL, NULL, NULL};
    // 创建Run loop observer对象
    // 第一个参数用于分配该observer对象的内存
    // 第二个参数用以设置该observer所要关注的的事件，详见回调函数myRunLoopObserver中注释
    // 第三个参数用于标识该observer是在第一次进入run loop时执行还是每次进入run loop处理时均执行
    // 第四个参数用于设置该observer的优先级
    // 第五个参数用于设置该observer的回调函数
    // 第六个参数用于设置该observer的运行环境
    CFRunLoopObserverRef observer = CFRunLoopObserverCreate(kCFAllocatorDefault,kCFRunLoopAllActivities, YES, 0, &myRunLoopObserver, &context);
    if (observer){
        CFRunLoopRef cfLoop = [myRunLoop getCFRunLoop];
        CFRunLoopAddObserver(cfLoop, observer, kCFRunLoopDefaultMode);
    }
    [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(printMessage:) userInfo:nil repeats:YES];
    NSInteger loopCount = 2;
    
    do{
        [[NSRunLoop currentRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:1]];
        loopCount--;
    }while (loopCount);
}
void myCFTimerCallback(){
    NSLog(@"-----++++-------");
}
/**
 *
 *  自定义源
 *
 */
-(void)test7{
    NSThread* aThread = [[NSThread alloc] initWithTarget:self selector:@selector(test77) object:nil];
    self.aThread = aThread;
    [aThread start];
}
-(void)test77{
    NSLog(@"starting thread.......");
    
    NSRunLoop *myRunLoop = [NSRunLoop currentRunLoop];
    
   // 设置Run Loop observer的运行环境
    CFRunLoopObserverContext context = {0, (__bridge void *)(self), NULL, NULL, NULL};
    
    // 创建Run loop observer对象
    // 第一个参数用于分配该observer对象的内存
    // 第二个参数用以设置该observer所要关注的的事件，详见回调函数myRunLoopObserver中注释
    // 第三个参数用于标识该observer是在第一次进入run loop时执行还是每次进入run loop处理时均执行
    // 第四个参数用于设置该observer的优先级
    // 第五个参数用于设置该observer的回调函数
    // 第六个参数用于设置该observer的运行环境
    CFRunLoopObserverRef observer = CFRunLoopObserverCreate(kCFAllocatorDefault,kCFRunLoopAllActivities, YES, 0, &myRunLoopObserver, &context);
    if (observer){
        CFRunLoopRef cfLoop = [myRunLoop getCFRunLoop];
        CFRunLoopAddObserver(cfLoop, observer, kCFRunLoopDefaultMode);
    }
    
    _source = [[SQRunLoopSource alloc] init];
    [_source addToCurrentRunLoop];
    while (!self.aThread.isCancelled)
    {
        NSLog(@"We can do other work");
        [myRunLoop runMode:NSDefaultRunLoopMode beforeDate:[NSDate dateWithTimeIntervalSinceNow:5.0f]];
    }
    [_source invalidate];
    NSLog(@"finishing thread.........");
}
/**
 *
 *  自定义RunLoopModel
 *
 */
-(void)test8{
    [NSThread detachNewThreadSelector:@selector(test88) toTarget:self withObject:nil];
}
-(void)test88{
    NSRunLoop *runloop=[NSRunLoop currentRunLoop];
    CFRunLoopObserverContext context = {0, (__bridge void *)(self), NULL, NULL, NULL};
       CFRunLoopObserverRef observer = CFRunLoopObserverCreate(kCFAllocatorDefault,kCFRunLoopAllActivities, YES, 0, &myRunLoopObserver, &context);
    if (observer){
        CFRunLoopRef cfLoop = [runloop getCFRunLoop];
        CFRunLoopAddObserver(cfLoop, observer, kCFRunLoopCommonModes);
    }
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(printMessage:) userInfo:nil repeats:YES];
    
    NSTimer *timer2 = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(printMessage:) userInfo:nil repeats:YES];
    
    [timer2 setFireDate:[NSDate dateWithTimeIntervalSinceNow:25.0]];
//    [NSTimer timerWithTimeInterval:1 target:self selector:@selector(printMessage:) userInfo:nil repeats:YES];
    [runloop addTimer:timer forMode:NSRunLoopCommonModes];
    [runloop addTimer:timer2 forMode:NSRunLoopCommonModes];
    CFRunLoopAddCommonMode(CFRunLoopGetCurrent(), (__bridge CFStringRef)(CustomRunLoopMode));
//    [timer fire];
    
//    do {
//
        [[NSRunLoop currentRunLoop] runMode:CustomRunLoopMode beforeDate:[NSDate dateWithTimeIntervalSinceNow:10.0]];
//    } while (_end);
    NSLog(@"finishing thread.........");
}
/**
 *
 *  配置基于port的源
 *  配置port源可以为线程保活，timer与source0不能影响runloop的运行逻辑，也不能b为线程保活
 */
-(void)test9{
    NSRunLoop *runloop=[NSRunLoop currentRunLoop];
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(printMessage:) userInfo:nil repeats:YES];
    [runloop addTimer:timer forMode:NSRunLoopCommonModes];
    [runloop addPort:[NSPort port] forMode:NSRunLoopCommonModes];
//    while (_end)
//    {
//        SInt32 result = CFRunLoopRunInMode(kCFRunLoopDefaultMode, 2, YES);
//    }
    CFRunLoopObserverContext context = {0, (__bridge void *)(self), NULL, NULL, NULL};
       CFRunLoopObserverRef observer = CFRunLoopObserverCreate(kCFAllocatorDefault,kCFRunLoopAllActivities, YES, 0, &myRunLoopObserver, &context);
    if (observer){
        CFRunLoopRef cfLoop = [runloop getCFRunLoop];
        CFRunLoopAddObserver(cfLoop, observer, kCFRunLoopCommonModes);
    }
//    do {
//
        [[NSRunLoop currentRunLoop] runMode:CustomRunLoopMode beforeDate:[NSDate dateWithTimeIntervalSinceNow:10.0]];
//    } while (_end);
    NSLog(@"finishing thread.........");
}
@end
