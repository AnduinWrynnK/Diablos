//
//  SQRunLoopSource.m
//  runloop
//
//  Created by xu yongpan on 2020/2/24.
//  Copyright © 2020 xu yongpan. All rights reserved.
//

#import "SQRunLoopSource.h"
#import "AppDelegate.h"
@interface SQRunLoopSource()
@property (nonatomic,weak) NSTimer *timer;


@end
@implementation SQRunLoopSource
/**
*
*  安装输入源到Run Loop－－－分两步首先初始化一个输入源(init)，然后将这个输入源添加到当前Run Loop里面(addToCurrentRunLoop)
*
*/
-(id)init
{
    CFRunLoopSourceContext context= {
      0,
        (__bridge void *)self,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        &RunLoopSourceScheduleRoutine,
        RunLoopSourceCancelRoutine,
        RunLoopSourcePerformRoutine
    };
    runLoopSource = CFRunLoopSourceCreate(NULL, 0, &context);
    commands = [[NSMutableArray alloc] init];
    return self;
}
-(void)addToCurrentRunLoop{
    //获取当前线程
    CFRunLoopRef runLoop = CFRunLoopGetCurrent();
    CFRunLoopAddSource(runLoop, runLoopSource, kCFRunLoopDefaultMode);
}
-(void)sourceFired{
    NSLog(@"输入源已发送信号");
    NSThread *thread = [NSThread currentThread];//结束当前线程任务
    [thread cancel];
}
-(void)addCommand:(NSInteger)command withData:(id)data{
    
}
//唤起当前线程
-(void)fireCommandsOnRunLoop:(CFRunLoopRef)runloop{
    CFRunLoopSourceSignal(runLoopSource);
    CFRunLoopWakeUp(runloop);
}
-(void)timerAction:(NSTimer *)timer{
    NSLog(@"---+++++++++++---");
}
-(void)invalidate{
    CFRunLoopRef runloop=CFRunLoopGetCurrent();
    CFRunLoopRemoveSource(runloop, runLoopSource, kCFRunLoopDefaultMode);
}

@end

@implementation RunLoopContext

-(id)initWithSource:(SQRunLoopSource *)src andLoop:(CFRunLoopRef)loop{
    if (self=[super init]) {
        _runLoop = loop;
         _source = src;
    }
    return self;
}

@end
/**
*  调度例程
*  当将输入源安装到run loop后，主线程执行APPDelegate的registerSource方法
*
*/
void RunLoopSourceScheduleRoutine(void *info, CFRunLoopRef rl,CFStringRef mode){
    SQRunLoopSource *obj=(__bridge SQRunLoopSource*)info;
    AppDelegate     *delegate=[[UIApplication sharedApplication] delegate];
    RunLoopContext  *theContext=[[RunLoopContext alloc] initWithSource:obj andLoop:rl];
    [delegate performSelectorOnMainThread:@selector(registerSource:) withObject:theContext waitUntilDone:true];//wait在主线程执行完此任务前是否阻塞当前线程
    
}
/**
*  处理例程
*  在输入源被告知（signal source）时，调用self的courcefired方法。
*
*/
void RunLoopSourcePerformRoutine(void *info){
    SQRunLoopSource *obj=(__bridge SQRunLoopSource*)info;
    [obj sourceFired];
}
/**
*  取消例程
*  如果使用CFRunLoopSourceInvalidate/CFRunLoopRemoveSource函数把输入源从run loop里面移除的话，系统会调用这个取消例程，并且把输入源从注册的客户端（可以理解为其他线程）里面移除
*
*/
void RunLoopSourceCancelRoutine(void *info, CFRunLoopRef rl,CFStringRef mode){
    SQRunLoopSource *obj=(__bridge SQRunLoopSource*)info;
    AppDelegate     *delegate=[[UIApplication sharedApplication] delegate];
    RunLoopContext  *theContext=[[RunLoopContext alloc] initWithSource:obj andLoop:rl];
    [delegate performSelectorOnMainThread:@selector(removeSource:) withObject:theContext waitUntilDone:false];
}
