//
//  SceneDelegate.h
//  runloop
//
//  Created by xu yongpan on 2020/2/18.
//  Copyright © 2020 xu yongpan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

