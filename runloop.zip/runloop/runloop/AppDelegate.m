//
//  AppDelegate.m
//  runloop
//
//  Created by xu yongpan on 2020/2/18.
//  Copyright © 2020 xu yongpan. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()
@property (nonatomic, readwrite, strong) NSMutableArray *sources;
@end

@implementation AppDelegate
-(id)init{
    if (self=[super init]) {
        self.sources = [NSMutableArray array];
    }
    return self;
}
+(AppDelegate *)sharedAppDelegate{
    static AppDelegate *thePTAppDelegate=nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        thePTAppDelegate=[[AppDelegate alloc] init];
    });
    return thePTAppDelegate;
}
/**
 *
 *  协调输入源的客户端（将输入源注册到客户端）
 *
 */
- (void)registerSource:(RunLoopContext*)sourceContext
{
  
    [self.sources addObject:sourceContext];//当source注入runloop时delegate的sources组也加入对应context；
    [self fireSource];
}
-(void)fireSource{
    if (self.sources.count>0) {//任务添加时，遍历任务数组，触发第一个任务发送
        RunLoopContext  *firstContext=[self.sources objectAtIndex:0];
        CFRunLoopRef    runLoop=firstContext.runLoop;
        SQRunLoopSource *source=firstContext.source;
        [source fireCommandsOnRunLoop:runLoop];//触发输入源发送消息
    }
}
- (void)removeSource:(RunLoopContext*)sourceContext
{
    id objToRemove = nil;
    for (RunLoopContext *context in self.sources) {
        if ([context isEqual:sourceContext]) {
            objToRemove=context;
            break;
        }
    }
    if (objToRemove) {
        [self.sources removeObject:objToRemove];
    }
//    [self.sources removeObject:sourceContext];
}
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    return YES;
}


#pragma mark - UISceneSession lifecycle


- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options {
    // Called when a new scene session is being created.
    // Use this method to select a configuration to create the new scene with.
    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration" sessionRole:connectingSceneSession.role];
}


- (void)application:(UIApplication *)application didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions {
    // Called when the user discards a scene session.
    // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
    // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
}


@end
