//
//  AppDelegate.h
//  runloop
//
//  Created by xu yongpan on 2020/2/18.
//  Copyright © 2020 xu yongpan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SQRunLoopSource.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;
- (void)registerSource:(RunLoopContext*)sourceContext;
- (void)removeSource:(RunLoopContext*)sourceContext;


+(AppDelegate *)sharedAppDelegate;
@end

