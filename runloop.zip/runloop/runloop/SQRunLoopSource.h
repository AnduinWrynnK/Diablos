//
//  SQRunLoopSource.h
//  runloop
//
//  Created by xu yongpan on 2020/2/24.
//  Copyright © 2020 xu yongpan. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SQRunLoopSource : NSObject
{
    CFRunLoopSourceRef runLoopSource;//输入信号
    NSMutableArray     *commands;//常用数组
}

-(id)init;//初始化
-(void)addToCurrentRunLoop;//将输入源添加到当前循环
-(void)sourceFired;//输入源触发

-(void)addCommand:(NSInteger)command withData:(id)data;//?
-(void)fireCommandsOnRunLoop:(CFRunLoopRef)runloop;//运行所有的command Mode类型的事件 （Command到底是什么？与Source有什么关系）
-(void)invalidate;//定时器注销
@end

@interface RunLoopContext : NSObject
//{
//    CFRunLoopRef    _runLoop;
//    SQRunLoopSource *_source;
//}
@property(readonly) CFRunLoopRef     runLoop;
@property(readonly) SQRunLoopSource  *source;

-(id)initWithSource:(SQRunLoopSource*)src andLoop:(CFRunLoopRef)loop;
@end

void RunLoopSourceScheduleRoutine(void *info, CFRunLoopRef rl,CFStringRef mode);
void RunLoopSourcePerformRoutine(void *info);
void RunLoopSourceCancelRoutine(void *info, CFRunLoopRef rl,CFStringRef mode);

NS_ASSUME_NONNULL_END
